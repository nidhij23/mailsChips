import { Component, OnInit } from '@angular/core';
import {AccordionModule} from 'ng2-accordion';

@Component({
  selector: 'app-new2',
  templateUrl: './new2.component.html',
  styleUrls: ['./new2.component.css']
})
export class New2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
