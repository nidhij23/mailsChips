import { Component, OnInit } from '@angular/core';
import {AccordionModule} from 'ng2-accordion';
import {TagInputModule} from 'ng2-tag-input';
import { Http } from '@angular/http';
import { Observable } from 'rxjs';
import {
    Validators,
    FormGroup,
    FormControl
} from '@angular/forms';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/debounceTime';

@Component({
  selector: 'app-screen2',
  templateUrl: './screen2.component.html',
  styleUrls: ['./screen2.component.css']
})
export class Screen2Component implements OnInit {

   public items = ['Typescript', 'Angular2'];
    constructor( private http:  Http) {}

    ngOnInit() {
      
       
    }

    classification=['Normal Message','High Priority','Urgent']

   

   
}
