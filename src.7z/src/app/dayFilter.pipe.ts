import {Injectable,Pipe} from '@angular/core';

@Pipe({
    name:'dayFilter'
})
@Injectable()
export class DayFilter{

}